URL de l'application Web:

<https://share.streamlit.io/bchacun/equancy/StreamlitApp/main.py>

Lien Github:

<https://github.com/BChacun/Equancy.git>